#Currently on line 164 - need to make sure whether two-pass approach needed or not 
import sys, os, math 
class JackTokenizer: 
    def __init__(self, file: str): #opens the file and gets ready to tokenize it 
        self.symbols = {'{','}','[',']','(',')','.',',',';','+','-','*','/','&','|','<','>','=','~'}
        self.keywords = {'class','constructor','function','method','field','static','var','int','char','boolean','void','true','false','null','this','let','do','if','else','while','return'}
        self.ourfile = open(file,'r')
        all_tokens = []
        is_comment = False 
        is_slash = False 
        for line in self.ourfile: 
            for i,char in enumerate(line): 
                if char == '/' and line[i+1]=='*' and line[i+2] == '*': #handling comments 
                    is_comment = True 
                if char == '/' and line[i+1] == '/':
                    is_comment, is_slash = True, True 
                if is_comment == False and char != '\n' and char!= '\t':
                    all_tokens.append(char)
                if char ==  '/' and line[i-1] == '*' and i>0:
                    is_comment = False  
                if char == "\n" and is_comment == True and is_slash == True: 
                    is_comment = False 
                    is_slash = False 
        self.final_tokens = []
        temp = ""
        isString = False 
        for token in all_tokens:
            if token == '"' and isString == False: 
                isString = True 
            elif token == '"' and isString == True: 
                isString = False 
            if token in self.symbols:
                if temp: 
                    self.final_tokens.append(temp)
                self.final_tokens.append(token)
                temp = ''
                continue
            if token != ' ':
                temp+=token 
            elif token == ' ' and isString == True: 
                temp += token 
            elif token == ' ' and isString == False and temp: 
                self.final_tokens.append(temp)
                temp = ''
                continue
            if temp in self.keywords:
                self.final_tokens.append(temp)
                temp = ''
                continue
        #print(self.final_tokens)
        self.curind = -1
        self.max = len(self.final_tokens) - 1 
        self.curtoken = None 

    def hasMoreTokens(self) -> bool: #are there more tokens in the input? 
        if self.curind < self.max:
            return True 
        return False 
    
    def advance(self):
        self.curind += 1 
        self.curtoken = self.final_tokens[self.curind]
    
    def retreat(self):#new function added so we can look ahead for decisionmaking without committing to the move 
        self.curind -= 1 
        self.curtoken = self.final_tokens[self.curind]
    
    def tokenType(self) -> str:
        digs = {str(i) for i in range(10)}
        if self.curtoken in self.symbols:
            return "SYMBOL"
        elif self.curtoken in self.keywords:
            return "KEYWORD"
        elif self.curtoken[0] == '"' and self.curtoken[-1] == '"':
            return "STRING_CONST"
        for char in self.curtoken:
            if char not in digs: 
                return "IDENTIFIER"
        return "INT_CONST"
    
    def keyWord(self) -> str:
        if self.curtoken in self.keywords:
            return self.curtoken.upper()
    
    def symbol(self) -> str:
        if self.tokenType() == "SYMBOL":
            return self.curtoken

    def identifier(self) ->str:
        if self.tokenType() == "IDENTIFIER":
            return self.curtoken
    
    def intVal(self) -> int: 
        if self.tokenType() == "INT_CONST":
            return int(self.curtoken)
    
    def stringVal(self) ->str:
        if self.tokenType() == "STRING_CONST":
            return self.curtoken[1:-1]

class CompilationEngine:
    def __init__(self, inp: str, out: str):
        self.jack = JackTokenizer(inp)
        self.jack.advance() #initialize to the first token 
        self.writer = VMWriter(out)
        self.tabcount = 0
        self.escap = {"<":"&lt;",">":"&gt;",'"':'&quot;',"&":"&amp;"}
        self.mapper = {"STATIC":"static", "FIELD":"this","ARG":"argument","VAR":"local"}
        self.classSymbols = SymbolTable()
        self.subSymbols = SymbolTable()
        self.isMethod = False 
        self.isConstructor = False 
        self.classname = None 
        self.nlocals = 0
        self.nfields = 0 
        self.labelCount = 0

    def eat(self, s:str):
        if s == self.jack.curtoken:
            self.jack.advance()
        else: 
            ValueError("EAT NOT AS EXPECTED!")

    def compileClass(self): #no VM code genereated here 
        self.classSymbols.reset()
        self.eat('class')
        name = self.jack.curtoken
        self.classname = name 
        self.jack.advance()
        self.eat('{')
        self.nfields = 0 #resetting the field counter that will be used before constructor compilation 
        while self.jack.curtoken in {'static','field'}:
            self.compileClassVarDec()
        
        while self.jack.curtoken in {'constructor','function','method'}:
            self.compileSubroutine()
    
    def compileClassVarDec(self): #no VM code generated here 
        category = self.jack.curtoken.upper()
        self.jack.advance()
        dataType = self.jack.curtoken
        self.jack.advance()
        name = self.jack.curtoken
        self.classSymbols.define(name, dataType, category)
        if category == "FIELD":
            self.nfields += 1 
        self.jack.advance()
        while self.jack.curtoken == ',': #handling optional (',' varName)*
            self.jack.advance()
            name = self.jack.curtoken
            self.classSymbols.define(name, dataType, category)
            if category == "FIELD":
                self.nfields += 1 
            self.jack.advance()
        self.jack.advance()
        

    def compileSubroutine(self):
        self.subSymbols.reset()
        self.isMethod = False 
        self.isConstructor = False 
        if self.jack.curtoken == "method":
            self.isMethod = True 

        elif self.jack.curtoken == "constructor":
            self.isConstructor = True 
        
        self.jack.advance()
        self.jack.advance()
        name = self.classname + '.' + self.jack.curtoken#this is className.SubroutineName
        self.jack.advance()
        self.jack.advance()
        #removed the if-else statement from here and plugged it before compuleSubroutineBody
        self.compileParameterList()
        self.jack.advance()
        self.jack.advance()
        self.nlocals = 0 #resetting this number 
        while self.jack.curtoken == 'var':
            self.compileVarDec()
        #here we declare our VM statement 
        self.writer.writeFunction(name, self.nlocals)
        if self.isMethod == True: 
            self.subSymbols.define("this",self.classname,"ARG")
            self.writer.writePush("argument", 0)
            self.writer.writePop("pointer", 0)
        
        elif self.isConstructor == True: 
            self.writer.writePush("constant",self.nfields)
            self.writer.writeCall("Memory.alloc",1)
            self.writer.writePop("pointer",0)
            
        self.compileSubroutineBody()


    def compileParameterList(self):
        category = "ARG"
        if self.jack.curtoken != ')':
            dataType = self.jack.curtoken
            self.jack.advance()
            name = self.jack.curtoken
            self.subSymbols.define(name, dataType, category)
            self.jack.advance()
            while self.jack.curtoken == ',': #handling (',' type varName)*
                self.jack.advance()
                dataType = self.jack.curtoken
                self.jack.advance()
                name = self.jack.curtoken
                self.subSymbols.define(name, dataType, category)
                self.jack.advance()

    def compileSubroutineBody(self):
        self.compileStatements()
        self.jack.advance()
    
    def compileVarDec(self):
        category = "VAR"
        self.jack.advance()
        dataType = self.jack.curtoken 
        self.jack.advance()
        name = self.jack.curtoken 
        self.subSymbols.define(name, dataType, category)
        self.nlocals += 1 
        self.jack.advance()
        while self.jack.curtoken == ',': #handling (',' varName)*
            self.jack.advance()
            name = self.jack.curtoken
            self.subSymbols.define(name, dataType, category)
            self.nlocals += 1 
            self.jack.advance()
        self.jack.advance()

    
    def compileStatements(self):
        while self.jack.curtoken in {'let','if','while','do','return'}:
            if self.jack.curtoken == 'let':
                self.compileLet()
            elif self.jack.curtoken == 'if':
                self.compileIf()
            elif self.jack.curtoken == 'while':
                self.compileWhile()
            elif self.jack.curtoken == 'do':
                self.compileDo()
            elif self.jack.curtoken == 'return':
                self.compileReturn()

    
    def compileLet(self):
        self.jack.advance()  # 'let'
        name = self.jack.curtoken  # variable name
        category = self.subSymbols.kindOf(name)
        index = self.subSymbols.indexOf(name)
        
        if category == "NONE":
            category = self.classSymbols.kindOf(name)
            index = self.classSymbols.indexOf(name)

        if category == "NONE":
            raise ValueError(f"Variable '{name}' is not defined.")

        self.jack.advance()

        # Array access: varName[index] = expression
        if self.jack.curtoken == '[':
            self.jack.advance()  # Skip '['
            self.compileExpression()  # Compile the index expression
            self.writer.writePush(self.mapper[category], index)  # Push base address of the array
            self.writer.writeArithmetic("add")  # Base address + index
            self.jack.advance()  # Skip ']'
            
            self.jack.advance()  # Skip '='
            self.compileExpression()  # Compile the expression to assign

            self.writer.writePop("temp", 0)  # Store the value in a temporary location
            self.writer.writePop("pointer", 1)  # Set `that` to base + index
            self.writer.writePush("temp", 0)  # Push the value to be assigned
            self.writer.writePop("that", 0)  # Assign value to the array element via `that`

            self.jack.advance()  # Skip ';'
        else:
            # Regular assignment: varName = expression
            self.jack.advance()  # Skip '='
            self.compileExpression()
            self.writer.writePop(self.mapper[category], index)
            self.jack.advance()  # Skip ';'


    def compileIf(self):
        self.jack.advance()
        self.jack.advance()
        self.compileExpression()
        self.writer.writeArithmetic("not")
        label1 = self.classname + '.' + str(self.labelCount)
        self.labelCount += 1 
        label2 = self.classname + '.' + str(self.labelCount)
        self.labelCount += 1
        self.writer.writeIf(label1) 
        self.jack.advance()
        self.jack.advance()
        self.compileStatements()
        self.writer.writeGoto(label2)
        self.writer.writeLabel(label1)
        self.jack.advance()
        if self.jack.curtoken == 'else':
            self.jack.advance()
            self.jack.advance()
            self.compileStatements()
            self.jack.advance()
        self.writer.writeLabel(label2)

    def compileWhile(self):
        self.jack.advance()
        self.jack.advance()
        label1 = self.classname + '.' + str(self.labelCount)
        self.labelCount += 1 
        label2 = self.classname + '.' + str(self.labelCount)
        self.labelCount += 1
        self.writer.writeLabel(label1)
        self.compileExpression()
        self.writer.writeArithmetic("not")
        self.writer.writeIf(label2)
        self.jack.advance()
        self.jack.advance()
        self.compileStatements()
        self.writer.writeGoto(label1)
        self.writer.writeLabel(label2)
        self.jack.advance()

    def compileDo(self):
        self.jack.advance()  
        subroutineName = self.jack.curtoken
        isMethodCall = False
        self.jack.advance()

        if self.jack.curtoken == '.':
            self.jack.advance()
            subroutineName += '.' + self.jack.curtoken
            self.jack.advance()

            objName = subroutineName.split('.')[0]
            # Check both subroutine-level and class-level symbols
            if self.subSymbols.kindOf(objName) != "NONE" or self.classSymbols.kindOf(objName) != "NONE":
                isMethodCall = True

        self.jack.advance()
        nArgs = self.compileExpressionList()

        if isMethodCall:
            objName = subroutineName.split('.')[0]
            if self.subSymbols.kindOf(objName) != "NONE":
                segment = self.mapper[self.subSymbols.kindOf(objName)]
                index = self.subSymbols.indexOf(objName)
            elif self.classSymbols.kindOf(objName) != "NONE":
                segment = self.mapper[self.classSymbols.kindOf(objName)]
                index = self.classSymbols.indexOf(objName)
            else:
                raise ValueError(f"Object '{objName}' is not defined.")
            self.writer.writePush(segment, index)
            nArgs += 1

        self.jack.advance()
        self.writer.writeCall(subroutineName, nArgs)
        self.writer.writePop("temp", 0)
        self.jack.advance()



    def compileReturn(self):
        self.jack.advance()

        if self.jack.curtoken != ';':
            self.compileExpression()
        else:
            self.writer.writePush("constant", 0)

        self.writer.writeReturn()
        self.jack.advance()



    def compileExpression(self):
        # Compile the first term
        self.compileTerm()
        
        # While the current token is a binary operator, compile the rest of the expression
        while self.jack.curtoken in ['+', '-', '*', '/', '&', '|', '<', '>', '=']:
            operator = self.jack.curtoken
            self.jack.advance()
            self.compileTerm()  # Compile the next term
            
            # Handle the operator using helper method to map VM commands
            self.handleBinaryOperator(operator)
        

    def compileTerm(self):
        if self.jack.tokenType() == "INT_CONST":
            # Push integer constant
            self.writer.writePush("constant", self.jack.intVal())
            self.jack.advance()

        elif self.jack.tokenType() == "STRING_CONST":
            stringVal = self.jack.stringVal()
            # Allocate space for string and push characters
            self.writer.writePush("constant", len(stringVal))
            self.writer.writeCall("String.new", 1)
            for char in stringVal:
                self.writer.writePush("constant", ord(char))
                self.writer.writeCall("String.appendChar", 2)
            self.jack.advance()

        elif self.jack.curtoken in ['true', 'false', 'null', 'this']:
            # Handle keyword constants
            if self.jack.curtoken == 'true':
                self.writer.writePush("constant", 1)
                self.writer.writeArithmetic("neg")  # true is represented as -1
            elif self.jack.curtoken in ['false', 'null']:
                self.writer.writePush("constant", 0)
            elif self.jack.curtoken == 'this':
                self.writer.writePush("pointer", 0)  # 'this' points to the base of the current object
            self.jack.advance()

        elif self.jack.curtoken == '(':
            # Handle expressions in parentheses
            self.jack.advance()  # Skip '('
            self.compileExpression()  # Compile the expression inside parentheses
            self.jack.advance()  # Skip ')'

        elif self.jack.curtoken in ['-', '~']:
            # Handle unary operators (- and ~)
            unary_op = self.jack.curtoken
            self.jack.advance()
            self.compileTerm()
            if unary_op == '-':
                self.writer.writeArithmetic("neg")
            elif unary_op == '~':
                self.writer.writeArithmetic("not")

        elif self.jack.tokenType() == "IDENTIFIER":
            # Handle variable names, array access, and subroutine calls
            name = self.jack.curtoken
            self.jack.advance()

            # Array access: varName[index]
            if self.jack.curtoken == '[':
                self.jack.advance()  # Skip '['
                self.compileExpression()  # Compile the index expression
                self.jack.advance()  # Skip ']'

                # Push the base address of the array (either subroutine or class scope)
                if self.subSymbols.kindOf(name) != "NONE":
                    segment = self.mapper[self.subSymbols.kindOf(name)]
                    index = self.subSymbols.indexOf(name)
                else:
                    segment = self.mapper[self.classSymbols.kindOf(name)]
                    index = self.classSymbols.indexOf(name)

                self.writer.writePush(segment, index)
                self.writer.writeArithmetic("add")  # Compute base address + index
                self.writer.writePop("pointer", 1)  # Set 'that' to base + index
                self.writer.writePush("that", 0)  # Push the value of the array element

            # Subroutine call: varName(subroutineName or className.subroutineName)
            elif self.jack.curtoken == '(':
                # Handle subroutine call on the current object (method)
                self.jack.advance()
                nArgs = self.compileExpressionList()
                self.jack.advance()  # Skip ')'
                self.writer.writeCall(self.classname + "." + name, nArgs)

            elif self.jack.curtoken == '.':
                # Handle subroutine call on another class or object
                self.jack.advance()  # Skip '.'
                subroutine_name = self.jack.curtoken
                self.jack.advance()  # Skip the subroutine name
                self.jack.advance()  # Skip '('
                nArgs = self.compileExpressionList()
                self.jack.advance()  # Skip ')'
                self.writer.writeCall(name + "." + subroutine_name, nArgs)

            else:
                # Handle simple variable access (without array or subroutine call)
                if self.subSymbols.kindOf(name) != "NONE":
                    segment = self.mapper[self.subSymbols.kindOf(name)]
                    index = self.subSymbols.indexOf(name)
                else:
                    segment = self.mapper[self.classSymbols.kindOf(name)]
                    index = self.classSymbols.indexOf(name)

                self.writer.writePush(segment, index)  # Push variable value to the stack

    def compileExpressionList(self):
        nArgs = 0

        if self.jack.curtoken != ')':
            self.compileExpression()
            nArgs += 1

            while self.jack.curtoken == ',':
                self.jack.advance()
                self.compileExpression()
                nArgs += 1

        return nArgs

    def handleBinaryOperator(self, operator):
        if operator == '+':
            self.writer.writeArithmetic("add")
        elif operator == '-':
            self.writer.writeArithmetic("sub")
        elif operator == '*':
            self.writer.writeCall("Math.multiply", 2)
        elif operator == '/':
            self.writer.writeCall("Math.divide", 2)
        elif operator == '&':
            self.writer.writeArithmetic("and")
        elif operator == '|':
            self.writer.writeArithmetic("or")
        elif operator == '<':
            self.writer.writeArithmetic("lt")
        elif operator == '>':
            self.writer.writeArithmetic("gt")
        elif operator == '=':
            self.writer.writeArithmetic("eq")

class SymbolTable:
    def __init__(self):
        self.table = {} #of the form "name": [type, kind, index] eg. [point, STATIC, 1]
        self.indices = {"STATIC": 0, "FIELD": 0, "ARG": 0, "VAR": 0}
    
    def reset(self):
        self.table = {} 
        self.indices = {"STATIC": 0, "FIELD": 0, "ARG": 0, "VAR": 0}
    
    def define(self, name: str, type: str, kind: str):
        self.table[name] = [type, kind, self.indices[kind]]
        self.indices[kind] += 1 
    
    def varCount(self, kind: str) -> int: 
        return self.indices[kind]

    def kindOf(self, name: str) -> str: 
        if name in self.table:
            return self.table[name][1]
        else: 
            return "NONE"
    
    def typeOf(self, name:str) -> str: 
        if name in self.table:
            return self.table[name][0]
        return "NONE"

    def indexOf(self, name: str) -> int: 
        if name in self.table:
            return self.table[name][2]
        else: 
            return "NONE"

class VMWriter:
    def __init__(self, output: str):
        self.outfile = open(output,'w')
    
    def writePush(self, segment: str, index: int):
        self.outfile.write(f'push {segment} {index}\n')
    
    def writePop(self, segment: str, index: int):
        self.outfile.write(f'pop {segment} {index}\n')
    
    def writeArithmetic(self, command: str):
        self.outfile.write(f'{command}\n')
    
    def writeLabel(self, label: str):
        self.outfile.write(f'label {label}\n')
    
    def writeGoto(self, label: str):
        self.outfile.write(f'goto {label}\n')
    
    def writeIf(self, label: str):
        self.outfile.write(f'if-goto {label}\n')
    
    def writeCall(self, name: str, nArgs: int):
        self.outfile.write(f'call {name} {nArgs}\n')
    
    def writeFunction(self, name: str, nVars: int):
        self.outfile.write(f'function {name} {nVars}\n')
    
    def writeReturn(self):
        self.outfile.write(f'return\n')
    
    def close(self):
        self.outfile.close()





def main():
    inputarg = sys.argv[1]
    #inputarg = '/Users/adityapatel/Desktop/CS-MOOCS/nand2tetris ii/W5/2. ConvertToBin'
    all_inputs = []
    fullpath = os.path.abspath(inputarg)
    
    if fullpath.endswith('.jack'):
        all_inputs.append(fullpath)
    else:
        for file in os.listdir(fullpath):
            if file.endswith('.jack'):
                all_inputs.append(os.path.join(fullpath, file))
    
    for inp in all_inputs:
        base_name = os.path.splitext(os.path.basename(inp))[0]
        outFileName = os.path.join(os.path.dirname(inp), base_name + '.vm')
        engine = CompilationEngine(inp, outFileName)
        engine.compileClass()


if __name__ == "__main__":
    main()