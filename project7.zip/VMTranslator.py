import sys 

class Parser: 
    def __init__(self,file:str): #opens the input file and gets ready to parse it 
        self.ourfile = open(file,'r')
        self.all_lines = []
        self.nextpos = 0
        self.curins = None 

        for line in self.ourfile: #writing all the raw instructions in a list for easy parsing 
            if line[-1] == "\n": 
                if line[:-1].strip() != "":
                    if line[:-1].strip()[0] != "/": 
                        self.all_lines.append(line[:-1].strip().replace(" ",""))
            else: 
                if line.strip() != "":
                    if line.strip()[0] != "/": 
                        self.all_lines.append(line.strip().replace(" ",""))

        self.ourfile.close()
        self.lastins = len(self.all_lines) -1  #location of the last instruction is key 
        self.arith = {"add","sub","neg","eq","gt","lt","and","or","not"}
        self.digs = {str(i) for i in range(10)}
    
    def hasMoreLines(self) -> bool: #are there any more lines in the input? 
        if self.nextpos <= self.lastins:
            return True 
        else: 
            return False
    
    def advance(self): #skip over whitespace and comments, read next instruction from input and make it current 
        if self.hasMoreLines:
            self.curins = self.all_lines[self.nextpos]
            self.nextpos += 1 
    
    def commandType(self) -> str: #returns the type of current command. If it is an arithmetic one then returns C_ARITHMETIC. C_PUSH, C_POP ;;; C_LABEL, C_GOTO, C_IF, C_FUNCTION, C_RETURN, C_CALL. 
        if self.curins == None:
            return None 
        elif self.curins in self.arith:
            return "C_ARITHMETIC"
        elif self.curins[:3] == "pop":
            return "C_POP"
        elif self.curins[:4] == "push":
            return "C_PUSH"
        
    def arg1(self) -> str: #returns the first argument of the current command. In case of C_ARITHMETIC return the command itself (add,sub etc)
        if self.commandType() == "C_RETURN":
            return None 
        if self.commandType() == "C_ARITHMETIC":
            return self.curins 
        elif self.commandType() == "C_PUSH":
            ans = ""
            for char in self.curins[4::]:
                if char not in self.digs:
                    ans+=char 
            return ans 
        elif self.commandType() == "C_POP":
            ans = ""
            for char in self.curins[3::]:
                if char not in self.digs: 
                    ans+=char 
            return ans 
    
    def arg2(self) -> int: #returns the second argument of the current command. Should be called only of the current command is C_PUSH, C_POP, C_FUNCTION or C_CALL. 
        if self.commandType() not in {"C_PUSH","C_POP","C_FUNCTION","C_CALL"}:
            return 
        elif self.commandType() == "C_PUSH":
            ans = ""
            for char in self.curins[4::]:
                if char in self.digs: 
                    ans+=char
            return int(ans) 
        elif self.commandType() == "C_POP":
            ans = ""
            for char in self.curins[3::]:
                if char in self.digs: 
                    ans += char 
            return int(ans) 

class CodeWriter: 
    def __init__(self, outfile: str, name: str):
        self.name = name 
        self.outfile = open(outfile,'w')
        self.falsecount = 0
        self.truecount = 0 
        self.endcount = 0 
        #also include one for filename for static varibale tracking 
    
    def writeArithmetic(self,command: str): #implement code to implement commands - add, sub, neg, eg, gt, lt, and, or, not. 
        if command == "add":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=D+M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M\n")
            self.outfile.write("M=D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M+1\n")
        
        elif command == "sub":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")

        elif command == "neg":
            self.outfile.write("@0\n")
            self.outfile.write("D=A\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D-M\n")

        elif command == "eq":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JNE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JEQ\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 

        elif command == "gt":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JLE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JGT\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 
        
        elif command == "lt":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JGE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JLT\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 
        
        elif command == "and":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D&M\n")
        
        elif command == "or":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D|M\n")
        
        elif command == "not":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=!M\n")

    
    def writePushPop(self, command: str, segment: str, index: int): #implement code to write assembly code to implement the given push or pop command 
        segmap = {"local":"LCL","argument":"ARG","this":"THIS","that":"THAT"}
        if command == "C_PUSH":
            if segment == "constant": 
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=A\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "pointer":
                if index == 0:
                    location = "THIS"
                elif index == 1: 
                    location = "THAT"
                self.outfile.write(f"@{location}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "static":
                self.outfile.write(f"@{self.name}.{index}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "temp":
                self.outfile.write(f"@{5+index}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            else: 
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=A\n")
                self.outfile.write(f"@{segmap[segment]}\n")
                self.outfile.write("A=D+M\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
                
        elif command == "C_POP": 
            if segment == "pointer":
                if index == 0:
                    location = "THIS"
                elif index == 1: 
                    location = "THAT"
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{location}\n")
                self.outfile.write("M=D\n")

            elif segment == "static":
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{self.name}.{index}\n")
                self.outfile.write("M=D\n")
            
            elif segment == "temp":
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{5+index}\n")
                self.outfile.write("M=D\n")
            
            else: 
                self.outfile.write(f"@{segmap[segment]}\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=D+A\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M+1\n")
                self.outfile.write("M=D\n")
                self.outfile.write("A=A-1\n")
                self.outfile.write("D=M\n")
                self.outfile.write("A=A+1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                
    
    def close(self): #closes te output file/stream 
        self.outfile.write('(END)\n')
        self.outfile.write(f'@END\n')
        self.outfile.write('0;JMP')
        self.outfile.close()

def main():
    #input_file = '/Users/adityapatel/Desktop/CS MOOCS/nand2tetris ii/W1/07/StackTest/StackTest copy.vm'
    input_file = sys.argv[1]
    name = getName(input_file)
    output_file = getOutfile(input_file) #during submission change this to a more functional format 
    parser = Parser(input_file)
    codewriter = CodeWriter(output_file,name)
    while parser.hasMoreLines():
        parser.advance()
        if parser.commandType() in {"C_PUSH",'C_POP'}:
            codewriter.writePushPop(parser.commandType(), parser.arg1(),parser.arg2())
        elif parser.commandType() == "C_ARITHMETIC":
            codewriter.writeArithmetic(parser.curins)
    codewriter.close()

def getName(input_file:str) -> str:
    return input_file.split('.')[0].split('/')[-1]

def getOutfile(input_file:str) -> str: 
    return input_file.split('.')[0] + '.asm'

if __name__ == "__main__":
    main()