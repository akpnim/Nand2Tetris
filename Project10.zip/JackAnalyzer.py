import sys, os, math 

class JackTokenizer: 
    def __init__(self, file: str): #opens the file and gets ready to tokenize it 
        self.symbols = {'{','}','[',']','(',')','.',',',';','+','-','*','/','&','|','<','>','=','~'}
        self.keywords = {'class','constructor','function','method','field','static','var','int','char','boolean','void','true','false','null','this','let','do','if','else','while','return'}
        self.ourfile = open(file,'r')
        all_tokens = []
        is_comment = False 
        is_slash = False 
        for line in self.ourfile: 
            for i,char in enumerate(line): 
                if char == '/' and line[i+1]=='*' and line[i+2] == '*': #handling comments 
                    is_comment = True 
                if char == '/' and line[i+1] == '/':
                    is_comment, is_slash = True, True 
                if is_comment == False and char != '\n' and char!= '\t':
                    all_tokens.append(char)
                if char ==  '/' and line[i-1] == '*' and i>0:
                    is_comment = False  
                if char == "\n" and is_comment == True and is_slash == True: 
                    is_comment = False 
                    is_slash = False 
        self.final_tokens = []
        temp = ""
        isString = False 
        for token in all_tokens:
            if token == '"' and isString == False: 
                isString = True 
            elif token == '"' and isString == True: 
                isString = False 
            if token in self.symbols:
                if temp: 
                    self.final_tokens.append(temp)
                self.final_tokens.append(token)
                temp = ''
                continue
            if token != ' ':
                temp+=token 
            elif token == ' ' and isString == True: 
                temp += token 
            elif token == ' ' and isString == False and temp: 
                self.final_tokens.append(temp)
                temp = ''
                continue
            if temp in self.keywords:
                self.final_tokens.append(temp)
                temp = ''
                continue
        #print(self.final_tokens)
        self.curind = -1
        self.max = len(self.final_tokens) - 1 
        self.curtoken = None 

    def hasMoreTokens(self) -> bool: #are there more tokens in the input? 
        if self.curind < self.max:
            return True 
        return False 
    
    def advance(self):
        self.curind += 1 
        self.curtoken = self.final_tokens[self.curind]
    
    def tokenType(self) -> str:
        digs = {str(i) for i in range(10)}
        if self.curtoken in self.symbols:
            return "SYMBOL"
        elif self.curtoken in self.keywords:
            return "KEYWORD"
        elif self.curtoken[0] == '"' and self.curtoken[-1] == '"':
            return "STRING_CONST"
        for char in self.curtoken:
            if char not in digs: 
                return "IDENTIFIER"
        return "INT_CONST"
    
    def keyWord(self) -> str:
        if self.curtoken in self.keywords:
            return self.curtoken.upper()
    
    def symbol(self) -> str:
        if self.tokenType() == "SYMBOL":
            return self.curtoken

    def identifier(self) ->str:
        if self.tokenType() == "IDENTIFIER":
            return self.curtoken
    
    def intVal(self) -> int: 
        if self.tokenType() == "INT_CONST":
            return int(self.curtoken)
    
    def stringVal(self) ->str:
        if self.tokenType() == "STRING_CONST":
            return self.curtoken[1:-1]

class CompilationEngine:
    def __init__(self, inp: str, out: str):
        self.jack = JackTokenizer(inp)
        self.jack.advance() #initialize to the first token 
        self.outfile = open(out,'w')
        self.tabcount = 0
        self.escap = {"<":"&lt;",">":"&gt;",'"':'&quot;',"&":"&amp;"}

    def eat(self, s:str):
        if s == self.jack.curtoken:
            self.jack.advance()
        else: 
            ValueError("EAT NOT AS EXPECTED!")

    def compileClass(self):
        self.outfile.write('<class>\n')
        self.tabcount += 1 
        self.eat('class')
        self.outfile.write('\t'*self.tabcount)
        self.outfile.write('<keyword> class </keyword>\n')
        self.outfile.write('\t'*self.tabcount)
        self.outfile.write(f'<identifier> {self.jack.curtoken} </identifier>\n')
        self.jack.advance()
        self.eat('{')
        self.outfile.write('\t'*self.tabcount)
        self.outfile.write('<symbol> { </symbol>\n')
        while self.jack.curtoken in {'static','field'}:
            self.compileClassVarDec()
        
        while self.jack.curtoken in {'constructor','function','method'}:
            self.compileSubroutine()
        
        self.outfile.write('\t'*self.tabcount)
        self.outfile.write('<symbol> } </symbol>\n')
        self.outfile.write('</class>')
    
    def compileClassVarDec(self):
        self.outfile.write('\t'*self.tabcount + '<classVarDec>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #static or field 
        self.jack.advance()
        if self.jack.curtoken in {'boolean','int','char'}: #now time to handle type
            self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n')
        else: 
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n')
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n')#handling varName
        self.jack.advance()
        while self.jack.curtoken == ',': #handling optional (',' varName)*
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling comma
            self.jack.advance()
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
            self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling semicolon
        self.jack.advance()
        self.tabcount -= 1 #at the end to manage indentation 
        self.outfile.write('\t'*self.tabcount + '</classVarDec>\n')
        

    def compileSubroutine(self):
        self.outfile.write('\t'*self.tabcount + '<subroutineDec>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #const. or func. or method
        self.jack.advance()
        if self.jack.curtoken in {'boolean','int','char','void'}:
            self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handling void 
        else: 
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling className
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling subroutineName
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling (
        self.jack.advance()
        self.compileParameterList()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling )
        self.jack.advance()
        self.compileSubroutineBody()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</subroutineDec>\n')

    def compileParameterList(self):
        self.outfile.write('\t'*self.tabcount + '<parameterList>\n')
        if self.jack.curtoken != ')':
            self.tabcount += 1 

            if self.jack.curtoken in {'boolean','int','char'}: #handling type 
                self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') 
            else: 
                self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n')
            self.jack.advance()

            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
            self.jack.advance()

            while self.jack.curtoken == ',': #handling (',' type varName)*
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ,
                self.jack.advance()
                if self.jack.curtoken in {'boolean','int','char'}: #handling type 
                    self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') 
                else: 
                    self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n')
                self.jack.advance()

                self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
                self.jack.advance()

            self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</parameterList>\n')

    def compileSubroutineBody(self):
        self.outfile.write('\t'*self.tabcount + '<subroutineBody>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling {
        self.jack.advance()
        while self.jack.curtoken == 'var':
            self.compileVarDec()
        self.compileStatements()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling }
        self.jack.advance()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</subroutineBody>\n')
    
    def compileVarDec(self):
        self.outfile.write('\t'*self.tabcount + '<varDec>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'var'
        self.jack.advance()

        if self.jack.curtoken in {'boolean','int','char'}: #handling type 
            self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') 
        else: 
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n')
        self.jack.advance()

        self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
        self.jack.advance()

        while self.jack.curtoken == ',': #handling (',' varName)*
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ,
            self.jack.advance()
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
            self.jack.advance()
        
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ;
        self.jack.advance()

        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</varDec>\n')

    
    def compileStatements(self):
        self.outfile.write('\t'*self.tabcount + '<statements>\n')
        self.tabcount += 1 
        while self.jack.curtoken in {'let','if','while','do','return'}:
            if self.jack.curtoken == 'let':
                self.compileLet()
            elif self.jack.curtoken == 'if':
                self.compileIf()
            elif self.jack.curtoken == 'while':
                self.compileWhile()
            elif self.jack.curtoken == 'do':
                self.compileDo()
            elif self.jack.curtoken == 'return':
                self.compileReturn()
        self.tabcount -= 1
        self.outfile.write('\t'*self.tabcount + '</statements>\n')
    
    def compileLet(self):
        self.outfile.write('\t'*self.tabcount + '<letStatement>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'let'
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName
        self.jack.advance()
        if self.jack.curtoken == '[':
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling [
            self.jack.advance()
            self.compileExpression()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ]
            self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling =
        self.jack.advance()
        self.compileExpression()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ;
        self.jack.advance()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</letStatement>\n')


    def compileIf(self):
        self.outfile.write('\t'*self.tabcount + '<ifStatement>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'if'
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling (
        self.jack.advance()
        self.compileExpression()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling )
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling {
        self.jack.advance()
        self.compileStatements()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling }
        self.jack.advance()
        if self.jack.curtoken == 'else':
            self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'else'
            self.jack.advance()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling {
            self.jack.advance()
            self.compileStatements()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling }
            self.jack.advance()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</ifStatement>\n')

    def compileWhile(self):
        self.outfile.write('\t'*self.tabcount + '<whileStatement>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'while'
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling (
        self.jack.advance()
        self.compileExpression()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling )
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling {
        self.jack.advance()
        self.compileStatements()
        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling }
        self.jack.advance()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</whileStatement>\n')

    def compileDo(self):
        self.outfile.write('\t'*self.tabcount + '<doStatement>\n')
        self.tabcount += 1 
        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'do'
        self.jack.advance()
        self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling subroutineName
        self.jack.advance()
        if self.jack.curtoken == '(':
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling (
            self.jack.advance()
            self.compileExpressionList()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling )
            self.jack.advance()
        else: 
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling '.'
            self.jack.advance()
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling subroutineName 
            self.jack.advance()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling '('
            self.jack.advance()
            self.compileExpressionList()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ')'
            self.jack.advance()

        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ';'
        self.jack.advance()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</doStatement>\n')



    def compileReturn(self):
        self.outfile.write('\t'*self.tabcount + '<returnStatement>\n')
        self.tabcount += 1 

        self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handing 'return'
        self.jack.advance()

        if self.jack.curtoken != ';':
            self.compileExpression()

        self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling ;
        self.jack.advance()

        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</returnStatement>\n')


    def compileExpression(self):
        self.outfile.write('\t'*self.tabcount + '<expression>\n')
        self.tabcount += 1 
        self.compileTerm()
        while self.jack.curtoken in {'+','-','*','/','&','|','<','>','='}:
            if self.jack.curtoken in self.escap:
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.escap[self.jack.curtoken]} </symbol>\n') #handling (op term)*
            else: 
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling (op term)*
            self.jack.advance()
            self.compileTerm()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</expression>\n')
        

    def compileTerm(self):
        self.outfile.write('\t'*self.tabcount + '<term>\n')
        self.tabcount += 1 
        if self.jack.tokenType() == "INT_CONST":
            self.outfile.write('\t'*self.tabcount + f'<integerConstant> {self.jack.curtoken} </integerConstant>\n') #handling INT CONST
            self.jack.advance()
        elif self.jack.tokenType() == "STRING_CONST":
            self.outfile.write('\t'*self.tabcount + f'<stringConstant> {self.jack.curtoken[1:-1]} </stringConstant>\n') #handling STRING CONST without ""
            self.jack.advance()
        elif self.jack.curtoken in {'true','false','null','this'}:
            self.outfile.write('\t'*self.tabcount + f'<keyword> {self.jack.curtoken} </keyword>\n') #handling keywords
            self.jack.advance()
        elif self.jack.curtoken == "(":
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling (
            self.jack.advance()
            self.compileExpression()
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling )
            self.jack.advance()
        elif self.jack.curtoken in {'-','~'}:
            self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling unary op 
            self.jack.advance()
            self.compileTerm()
        elif self.jack.tokenType() == "IDENTIFIER":
            self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling varName 
            self.jack.advance()
            if self.jack.curtoken == '[':
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling [
                self.jack.advance()
                self.compileExpression()
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling ]
                self.jack.advance()

            elif self.jack.curtoken == '(':
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling (
                self.jack.advance()
                self.compileExpressionList()
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n') #handling )
                self.jack.advance()
            
            elif self.jack.curtoken == '.':
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling '.'
                self.jack.advance()
                self.outfile.write('\t'*self.tabcount + f'<identifier> {self.jack.curtoken} </identifier>\n') #handling subroutineName 
                self.jack.advance()
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling '('
                self.jack.advance()
                self.compileExpressionList()
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ')'
                self.jack.advance()

        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</term>\n')

    def compileExpressionList(self):
        self.outfile.write('\t'*self.tabcount + '<expressionList>\n')
        self.tabcount += 1 
        if self.jack.tokenType() in {"INT_CONST","STRING_CONST","IDENTIFIER"} or self.jack.curtoken in {'-','~','true','false','null','this','('}:
            self.compileExpression()
            while self.jack.curtoken == ',':
                self.outfile.write('\t'*self.tabcount + f'<symbol> {self.jack.curtoken} </symbol>\n')#handling ','
                self.jack.advance()
                self.compileExpression()
        self.tabcount -= 1 
        self.outfile.write('\t'*self.tabcount + '</expressionList>\n')


def main():
    escap = {"<":"&lt;",">":"&gt;",'"':'&quot;',"&":"&amp;"}
    inputarg = sys.argv[1]
    #inputarg = "/Users/adityapatel/Desktop/CS-MOOCS/nand2tetris ii/W4/TestTokenizer"
    all_inputs = []
    fullpath = os.path.abspath(inputarg)
    if '.jack' in fullpath:
        all_inputs.append(fullpath)
    else: 
        allfiles = os.listdir(fullpath)
        allfiles = [fullpath+'/'+suff for suff in allfiles]
        ans = []
        for file in allfiles: 
            if file[-5::] == ".jack":
                all_inputs.append(file)

    for inp in all_inputs:
        tokenzier = JackTokenizer(inp)
        outFileName = inp.split('.')[0] + 'T' + '.xml'
        outFile = open(outFileName,'w')
        outFile.write('<tokens>\n')
        while tokenzier.hasMoreTokens() == True: 
            tokenzier.advance()
            tType = tokenzier.tokenType()
            curtoken = tokenzier.curtoken
            if tType == "SYMBOL":
                if curtoken in escap:
                    outFile.write(f'<symbol> {escap[curtoken]} </symbol>\n')
                else: 
                    outFile.write(f'<symbol> {curtoken} </symbol>\n')
            elif tType == "KEYWORD":
                outFile.write(f'<keyword> {curtoken} </keyword>\n')
            elif tType == "IDENTIFIER":
                outFile.write(f'<identifier> {curtoken} </identifier>\n')
            elif tType == "STRING_CONST":
                outFile.write(f'<stringConstant> {curtoken[1:-1]} </stringConstant>\n')
            elif tType == "INT_CONST":
                outFile.write(f'<integerConstant> {curtoken} </integerConstant>\n')
        outFile.write('</tokens>')
        #now that we are done writing our xxxT.xml file, lets write the xxx.xml file 
        outFileName = inp.split('.')[0] + '.xml'
        engine = CompilationEngine(inp,outFileName)
        engine.compileClass()


if __name__ == "__main__":
    main()