#For labelling functionality first we need to figure out that a commend is a label especially in push case- goto and ifgoto are trivial 
import sys 
import os 
class Parser: 
    def __init__(self,file:str): #opens the input file and gets ready to parse it 
        self.ourfile = open(file,'r')
        self.all_lines = []
        self.nextpos = 0
        self.curins = None 

        for line in self.ourfile: #writing all the raw instructions in a list for easy parsing 
            if line[-1] == "\n": 
                line = line[:-1]

            if ("function" in line or "call" in line):
                if "//" not in line:
                    self.all_lines.append(line.strip()) 
                elif '//' in line and line.strip().find('//')!=0: 
                    self.all_lines.append(line[:line.find("//")].strip())

            elif line.strip() != "":
                if line.strip()[0] != "/": 
                    cleanline = line.strip().replace(" ","")
                    finalind = cleanline.find("//")
                    if finalind == -1: 
                        finalind = len(cleanline)
                    final_line = cleanline[:finalind]
                    if final_line[-1] == "\t":
                        final_line = final_line[:-1]
                    self.all_lines.append(final_line)
        
        print(self.all_lines)

        self.ourfile.close()
        self.lastins = len(self.all_lines) -1  #location of the last instruction is key 
        self.arith = {"add","sub","neg","eq","gt","lt","and","or","not"}
        self.digs = {str(i) for i in range(10)}
    
    def hasMoreLines(self) -> bool: #are there any more lines in the input? 
        if self.nextpos <= self.lastins:
            return True 
        else: 
            return False
    
    def advance(self): #skip over whitespace and comments, read next instruction from input and make it current 
        if self.hasMoreLines:
            self.curins = self.all_lines[self.nextpos]
            self.nextpos += 1 
    
    def commandType(self) -> str: #returns the type of current command. If it is an arithmetic one then returns C_ARITHMETIC. C_PUSH, C_POP ;;; C_LABEL, C_GOTO, C_IF, C_FUNCTION, C_RETURN, C_CALL. 
        if self.curins == None:
            return None 
        elif self.curins in self.arith:
            return "C_ARITHMETIC"
        elif self.curins[:3] == "pop":
            return "C_POP"
        elif self.curins[:4] == "push":
            return "C_PUSH" 
        elif self.curins[:5] == "label":
            return "C_LABEL"
        elif self.curins[:4] == "goto":
            return "C_GOTO"
        elif self.curins[:7] == "if-goto":
            return "C_IF-GOTO"
        elif self.curins[:8] == "function":
            return "C_FUNCTION"
        elif self.curins[:6] == "return":
            return "C_RETURN"
        elif self.curins[:4] == "call":
            return "C_CALL"
        
        
    def arg1(self) -> str: #returns the first argument of the current command. In case of C_ARITHMETIC return the command itself (add,sub etc). For adding functionality for labels we need to create a dictionary to make sure 
        if self.commandType() == "C_RETURN":
            return None 
        if self.commandType() == "C_ARITHMETIC":
            return self.curins 
        elif self.commandType() == "C_PUSH":
            ans = ""
            for char in self.curins[4::]:
                if char not in self.digs:
                    ans+=char 
            return ans 
        elif self.commandType() == "C_POP":
            ans = ""
            for char in self.curins[3::]:
                if char not in self.digs: 
                    ans+=char 
            return ans 
        elif self.commandType() in {"C_LABEL","C_GOTO","C_IF-GOTO"}:
            return self.curins[len(self.commandType())-2::] #we do -2 to remove C_
    
    def arg2(self) -> int: #returns the second argument of the current command. Should be called only of the current command is C_PUSH, C_POP, C_FUNCTION or C_CALL. 
        if self.commandType() not in {"C_PUSH","C_POP","C_FUNCTION","C_CALL"}:
            return 
        elif self.commandType() == "C_PUSH":
            ans = ""
            for char in self.curins[4::]:
                if char in self.digs: 
                    ans+=char
            return int(ans) 
        elif self.commandType() == "C_POP":
            ans = ""
            for char in self.curins[3::]:
                if char in self.digs: 
                    ans += char 
            return int(ans) 

class CodeWriter: 
    def __init__(self, outfile: str, name: str):
        self.name = name 
        self.outfile = open(outfile,'w')
        self.falsecount = 0
        self.truecount = 0 
        self.endcount = 0 
        self.retcount = 0
        self.funstack = []
        self.curfunct = None 
        #also include one for filename for static varibale tracking 
    
    def writeArithmetic(self,command: str): #implement code to implement commands - add, sub, neg, eg, gt, lt, and, or, not. 
        if command == "add":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=D+M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M\n")
            self.outfile.write("M=D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M+1\n")
        
        elif command == "sub":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")

        elif command == "neg":
            self.outfile.write("@0\n")
            self.outfile.write("D=A\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D-M\n")

        elif command == "eq":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JNE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JEQ\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 

        elif command == "gt":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JLE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JGT\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 
        
        elif command == "lt":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("A=A-1\n")
            self.outfile.write("M=M-D\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write(f'@false{self.falsecount}\n')
            self.outfile.write("D;JGE\n")
            self.outfile.write(f"@true{self.truecount}\n")
            self.outfile.write("D;JLT\n")
            self.outfile.write(f"(false{self.falsecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=0\n")
            self.outfile.write(f"@END{self.endcount}\n")
            self.outfile.write("0;JMP\n")
            self.outfile.write(f"(true{self.truecount})\n")
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=-1\n")
            self.outfile.write(f"(END{self.endcount})\n")
            self.falsecount += 1 
            self.truecount += 1 
            self.endcount += 1 
        
        elif command == "and":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D&M\n")
        
        elif command == "or":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("D=M\n")
            self.outfile.write("@SP\n")
            self.outfile.write("M=M-1\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=D|M\n")
        
        elif command == "not":
            self.outfile.write("@SP\n")
            self.outfile.write("A=M-1\n")
            self.outfile.write("M=!M\n")

    
    def writePushPop(self, command: str, segment: str, index: int): #implement code to write assembly code to implement the given push or pop command 
        segmap = {"local":"LCL","argument":"ARG","this":"THIS","that":"THAT"}
        if command == "C_PUSH":
            if segment == "constant": 
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=A\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "pointer":
                if index == 0:
                    location = "THIS"
                elif index == 1: 
                    location = "THAT"
                self.outfile.write(f"@{location}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "static":
                self.outfile.write(f"@{self.name}.{index}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            elif segment == "temp":
                self.outfile.write(f"@{5+index}\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
            
            else: #this push is for digits of numbers only like push constant 30 etc. it doesnt handle push label commands yet 
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=A\n")
                self.outfile.write(f"@{segmap[segment]}\n")
                self.outfile.write("A=D+M\n")
                self.outfile.write("D=M\n")
                self.outfile.write("@SP\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M+1\n")
                
        elif command == "C_POP": 
            if segment == "pointer":
                if index == 0:
                    location = "THIS"
                elif index == 1: 
                    location = "THAT"
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{location}\n")
                self.outfile.write("M=D\n")

            elif segment == "static":
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{self.name}.{index}\n")
                self.outfile.write("M=D\n")
            
            elif segment == "temp":
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{5+index}\n")
                self.outfile.write("M=D\n")
            
            else: 
                self.outfile.write(f"@{segmap[segment]}\n")
                self.outfile.write("D=M\n")
                self.outfile.write(f"@{index}\n")
                self.outfile.write("D=D+A\n")
                self.outfile.write("@SP\n")
                self.outfile.write("M=M-1\n")
                self.outfile.write("A=M+1\n")
                self.outfile.write("M=D\n")
                self.outfile.write("A=A-1\n")
                self.outfile.write("D=M\n")
                self.outfile.write("A=A+1\n")
                self.outfile.write("A=M\n")
                self.outfile.write("M=D\n")
    
    def writeLabel(self, label: str): 
        #if self.funstack:
        #    label = self.funstack[-1] + '$' + label
        if self.curfunct: 
            label = self.curfunct + '$' + label 
        self.outfile.write(f'({label})\n')

    def writeIf(self, label: str): #nuance is that we need to pop the element 
        #if self.funstack:
        #    label = self.funstack[-1] + '$' + label
        if self.curfunct: 
            label = self.curfunct + '$' + label 
        self.outfile.write('@SP\n')
        self.outfile.write('A=M-1\n')
        self.outfile.write('D=M\n') 
        self.outfile.write('@SP\n')
        self.outfile.write('M=M-1\n')
        self.outfile.write(f'@{label}\n') 
        self.outfile.write('D;JNE\n')

    
    def writeGoto(self,label:str):
        #if self.funstack:
        #    label = self.funstack[-1] + '$' + label
        if self.curfunct: 
            label = self.curfunct + '$' + label 
        self.outfile.write(f'@{label}\n')
        self.outfile.write('0;JMP\n')
    
    def writeFunction(self, functionName:str, nVars:int):
        self.funstack.append(functionName) #adding to function stack to help maintain labels 
        self.curfunct = functionName
        self.outfile.write(f'({functionName})\n')
        for i in range(nVars):
            self.outfile.write('@0\n')
            self.outfile.write('D=A\n')
            self.outfile.write('@SP\n')
            self.outfile.write('A=M\n')
            self.outfile.write('M=D\n')
            self.outfile.write('@SP\n')
            self.outfile.write('M=M+1\n')
    
    def writeReturn(self):
        #self.funstack.pop() #removing the last function added to the funstack so we know which labels to use in current scope now 
        self.outfile.write('@LCL\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@13\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@5\n')
        self.outfile.write('D=A\n')
        self.outfile.write('@13\n')
        self.outfile.write('A=M-D\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@14\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M-1\n')
        self.outfile.write('A=M\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@ARG\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@ARG\n')
        self.outfile.write('D=M+1\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@13\n')
        self.outfile.write('A=M-1\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@THAT\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@2\n')
        self.outfile.write('D=A\n')
        self.outfile.write('@13\n')
        self.outfile.write('A=M-D\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@THIS\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@3\n')
        self.outfile.write('D=A\n')
        self.outfile.write('@13\n')
        self.outfile.write('A=M-D\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@ARG\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@4\n')
        self.outfile.write('D=A\n')
        self.outfile.write('@13\n')
        self.outfile.write('A=M-D\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@LCL\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@14\n')
        self.outfile.write('A=M\n')
        self.outfile.write('0;JMP\n')

    def writeCall(self, functionName:str, nArgs: int):
        self.outfile.write(f'@{functionName}$ret.{self.retcount}\n') #Xxx.foo$ret.i where i is self.retcount, Xxx.foo is functionname
        self.outfile.write('D=A\n')
        self.outfile.write('@SP\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M+1\n')
        self.outfile.write('@LCL\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@SP\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M+1\n')
        self.outfile.write('@ARG\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@SP\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M+1\n')
        self.outfile.write('@THIS\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@SP\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M+1\n')
        self.outfile.write('@THAT\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@SP\n')
        self.outfile.write('A=M\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=M+1\n')
        self.outfile.write('@SP\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@5\n')
        self.outfile.write('D=D-A\n')
        self.outfile.write(f'@{nArgs}\n')
        self.outfile.write('D=D-A\n')
        self.outfile.write('@ARG\n')
        self.outfile.write('M=D\n')
        self.outfile.write('@SP\n')
        self.outfile.write('D=M\n')
        self.outfile.write('@LCL\n')
        self.outfile.write('M=D\n')
        self.outfile.write(f'@{functionName}\n')
        self.outfile.write('0;JMP\n')
        self.outfile.write(f'({functionName}$ret.{self.retcount})\n')
        self.retcount += 1 
    
    def writeBoot(self):
        self.outfile.write('@256\n')
        self.outfile.write('D=A\n')
        self.outfile.write('@SP\n')
        self.outfile.write('M=D\n')
        self.writeCall("Sys.init",0)
        self.funstack.append("Sys.init")
        self.curfunct = "Sys.init"
    
    def close(self): #closes te output file/stream 
        self.outfile.write('(KHATAM)\n')
        self.outfile.write(f'@KHATAM\n')
        self.outfile.write('0;JMP')
        self.outfile.close()

def main():
    #inputarg = '/Users/adityapatel/Desktop/CS MOOCS/nand2tetris ii/W2/08/BasicLoop/BasicLoop.vm'
    inputarg = sys.argv[1]
    print("SADFDASFDSAFASDFDDS=",inputarg)
    allfiles = getFiles(inputarg)
    print("ALL_FILES=",allfiles)
    output_file = getOutfile(allfiles[0]) #creates one output file to write everything in
    name = getName(allfiles[0]) 
    codewriter = CodeWriter(output_file,name)

    if len(allfiles) > 1: #bootstrap code to be written 
        codewriter.writeBoot()

    for input_file in allfiles:
        newname = getName(input_file)
        codewriter.name = newname
        #print(input_file)
        parser = Parser(input_file)
        while parser.hasMoreLines():
            parser.advance()
            if parser.commandType() in {"C_PUSH",'C_POP'}:
                codewriter.writePushPop(parser.commandType(), parser.arg1(),parser.arg2())
            elif parser.commandType() == "C_ARITHMETIC":
                codewriter.writeArithmetic(parser.curins)
            elif parser.commandType() == "C_LABEL":
                codewriter.writeLabel(parser.arg1())
            elif parser.commandType() == "C_GOTO":
                codewriter.writeGoto(parser.arg1())
            elif parser.commandType() == "C_IF-GOTO":
                codewriter.writeIf(parser.arg1())
            elif parser.commandType() == "C_FUNCTION":
                breakup = parser.curins.split()
                f = breakup[1]
                nVars = int(breakup[2])
                codewriter.writeFunction(f,nVars) #xxx.foo functionality given as given in the contract where xxx is the filename and foo is the function name 
            elif parser.commandType() == "C_RETURN":
                codewriter.writeReturn()
            elif parser.commandType() == "C_CALL":
                breakup = parser.curins.split()
                #print(breakup)
                f = breakup[1]
                nArgs = int(breakup[2])
                codewriter.writeCall(f,nArgs)    
    codewriter.close()

def getName(input_file:str) -> str:
    ans = input_file.split('.')[0].split('/')[-1]
    return ans

def getOutfile(input_file:str) -> str: #problem here 
    ans = input_file.rsplit('/',2)
    final_ans = ans[0] + '/' + ans[1] + '/' + ans[1] + '.asm'
    #ans = input_file.split('.')[0] + '.asm'
    return final_ans

def getFiles(inputs:str) -> list:
    fullpath = os.path.abspath(inputs)
    if ".vm" in fullpath:
        return [fullpath]
    
    else:
        allfiles = os.listdir(fullpath)
        allfiles = [fullpath+'/'+suff for suff in allfiles]
        ans = []
        for file in allfiles: 
            if file[-3::] == ".vm":
                ans.append(file)
    return sorted(ans) #so that we maintain the same order each time for debugging purposes  


if __name__ == "__main__":
    main()